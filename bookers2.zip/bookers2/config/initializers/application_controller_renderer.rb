# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '8b7c411cbff30eb97362e42404a8f4469c504c775c2ec7e54200d1b40c0a303546ed54dc14a2b055c34021d07b710327a14282ceceef046e787ff9397335e4e2'